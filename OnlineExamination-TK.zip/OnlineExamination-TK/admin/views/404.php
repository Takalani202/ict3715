<?php

echo "Database has a connection error: " . $msg;

?>