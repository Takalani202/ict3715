<!-- Footer -->
<footer class="py-5 bg-dark mt-3" style="position: absolute; bottom:0; width:100%; height:0px;">
    <div class="container">
        <div class="m-0 text-center text-white">Copyright &copy; UNISA Online Exam Portal <?php echo date("Y"); ?>
        </div>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/datatables/datatables.min.js"></script>
<script src="assets/vendor/chart.js/Chart.min.js"></script>
<!-- <script src="assets/vendor/jquery/website.js"></script> -->

<script>
/* var stats = document.getElementById('regStud').getContext('2d');
var chart = new Chart(stats, {
    type: 'horizontalBar', // bar 
    data: {
        labels: <?php #echo json_encode($studentModule) ?>,
        datasets: [{
            label: 'Student registration statistics',
            data: <?php #echo json_encode($studentNumber) ?>, // background
            backgroundColor: '#cea3a3', // bar color 
            borderWidth: 1,
            borderColor: '#c1a149',
            hoverBorderWidth: 3,
            hoverBorderColor: '#00cbff'
        }]

    }
}); */
</script>
</body>

</html>