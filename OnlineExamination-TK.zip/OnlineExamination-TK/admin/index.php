<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'../inc/header.php');
?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="mt-5">UNISA Exam Control Panel - Admin</h1>
                
                <br/>
                <br/>

                <div class="jumbotron">
                    <h1>Controls</h1>
                   <!--  <a class="btn btn-outline-success btn-lg" href="index.php"><span class="fa fa-home"></span> Home</a> -->


                     <a class="btn btn-outline-info btn-lg" href="student.php"><span class="fa fa-user-circle"></span> Manage Student</a>

                      <a class="btn btn-outline-info btn-lg" href="module.php"><span class="fa fa-user-circle"></span> Manage Course</a>

                         <a class="btn btn-outline-primary btn-lg" href="report.php"><span class="fa fa-question-circle"></span> Reports</a>
                    <a class="btn btn-outline-info btn-lg" href="users.php"><span class="fa fa-user-circle"></span> Manage Users</a>
                 
                    <a class="btn btn-outline-dark btn-lg" href="queslist.php?action=list-exams"><span class="fa fa-list"></span> Manage Exam</a>
                    <!-- <a class="btn btn-outline-danger btn-lg" href="?action=logout"><span class="fa fa-sign-out"></span> Logout</a> -->

<BR> 

<?php
require_once("student_report.php"); 
echo '<br>'; 
require_once("module_report.php"); 
echo '<br>'; 
require_once("exam_report.php"); 

echo '<center>';
require_once("graph_report.php"); 

echo '</center> ';
?>
                   
                </div>

            </div>
        </div>
    </div>
<?php include '../inc/footer.php'; ?>