<?php  
//connect to database
$con = mysqli_connect('localhost', 'root', '');
       mysqli_select_db($con, 'oep_tk');

       
       $sql ="SELECT * FROM examsetup";
       $result = mysqli_query($con,$sql);
       echo  '<b>'.'Number of exam : '. $results_number = mysqli_num_rows($result) .'</b>'.' Exam';
       

       

?>