<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/User.php');
	$user = new User();
?>
<!-- <?php 
 //if (isset($_GET['dis'])) {
 	//$disid = (int)$_GET['dis'];
 	//$disuser = $user->disableUser($disid);
 //}
//
// if (isset($_GET['ena'])) {
 //	$enaid = (int)$_GET['ena'];
 //	$enauser = $user->enaUser($enaid);
 //}
  //if (isset($_GET['del'])) {
 //	$delid = (int)$_GET['del'];
 //	$deluser = $user->delUser($delid);
// }
?> -->
<?php require('connection.php'); // connection to db?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="mt-5">Manage Course</h1>
                <br/>
            </div>
<?php
 
 $sql = $db->prepare ("SELECT * FROM  `moduleinfo` ");
                               
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {

?>
<?php echo '<br>'.'<br>';?>



 <div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                    <tr>
                      
                        <th>Module Code</th>
                        <th>Descriptions</th>
                        <th>Action</th>
                  
                    </tr>
                    </thead>
                <tbody>


 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["ModCode"]."</td>".
           "<td>".$row["Description"]."</td>".
           // "<td>".$row["DAYS"]."</td>".
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}

?>
          
            </div>
        </div>
    </div>






<?php //include '../inc/footer.php'; ?>