<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/User.php');
	$user = new User();
?>
<!-- <?php 
 //if (isset($_GET['dis'])) {
 //	$disid = (int)$_GET['dis'];
 //	$disuser = $user->disableUser($disid);
// }

// if (isset($_GET['ena'])) {
 	$enaid = (int)$_GET['ena'];
 	$enauser = $user->enaUser($enaid);
// }
 // if (isset($_GET['del'])) {
 //	$delid = (int)$_GET['del'];
 //	$deluser = $user->delUser($delid);
//// }
?> -->

    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="mt-5">Manage Report</h1>
                <br/>
            </div>

<!-- 
            <div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>NAME</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                <tbody> -->
                    
<style>
    
table,th, td {
  border: 1px solid #D3F5B8;

/*  background-color: #96D4D4;*/
  /*border-collapse: collapse;*/
   width: 80%;
}
th, td {
 /* background-color: #96D4D4;*/
}
/*tr {
  background-color: #96D4D4;
}*/


</style>



<?php
require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT
                        COUNT(ModCode) 'TOTAL_COUNT',
                        DAYNAME(DateExam) 'SUBMIT_DAY'
                        FROM `exam_output`
                        WHERE NULLIF(DateExam,' ') IS NOT NULL
                        GROUP BY SUBMIT_DAY");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {
?>

<div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <h3>Summary report</h3>
                    <tr>
                       
                    
                        <th>Count number</th>
                
                        <th>Submitted day</th>
                    </tr>
                    </thead>
                <tbody>

<!-- <table >
   <tr >
    <h3>Trends report 1</h3>
     <td>Count number</td>
      <td>Submitted day</td>
      
   </tr> -->

 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["SUBMIT_DAY"]."</td>".
      
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}

// second report start here
//echo '<br>'.'<br>';

require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT
                                COUNT(ModCode) 'TOTAL_COUNT',
                                ModCode 'MODULES',
                                DAYNAME(DateExam) 'DAYS'
                                FROM `examsetup`
                                WHERE NULLIF(DateExam,' ') IS NOT NULL
                                GROUP BY DAYS
                                HAVING TOTAL_COUNT >= 1");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {

?>
<?php echo '<br>'.'<br>';?>



<!-- <table border="1">
   <tr COLSPAN=1 BGCOLOR="#ffb366">
    <h3>Trends report 2</h3>
     <td>Total count</td>
      <td>Modules</td>
      <td>Day</td>
   </tr> -->

 <div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <h3>Summary report</h3>
                    <tr>
                      
                        <th>Total count</th>
                        <th>Modules</th>
                  
                        <th>Day</th>
                    </tr>
                    </thead>
                <tbody>


 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["MODULES"]."</td>".
           "<td>".$row["DAYS"]."</td>".
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}


// }


require('connection.php'); // connection to db

$sql = $db->prepare("SELECT studentinfo.StudentNumber,StudentName,exam_output.ModCode, COUNT(studentinfo.StudentNumber) AS 'Total_Count' FROM studentinfo INNER JOIN exam_output ON exam_output.StudentNumber= studentinfo.StudentNumber WHERE exam_output.ModCode LIKE 'ICT%' OR exam_output.ModCode LIKE 'ict%' GROUP BY exam_output.ModCode HAVING COUNT(exam_output.StudentNumber) > 3 ORDER BY StudentNumber");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {


?>
 <?php echo '<br>'.'<br>';?>



<div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <h3>Trends report 3</h3>
                    <thead>
                    <tr>
                      
                        <th>Student Number</th>
                        <th>Student Name</th>
                  
                        <th>Module Code</th>
                         <th>Total Count</th>
                    </tr>
                    </thead>
                <tbody>

 <?php     
  while($row=$sql->fetch()) 
  {
       echo "<tr>".
        "<td>".$row["StudentNumber"]."</td>".
           "<td>".$row["StudentName"]."</td>".
            "<td>".$row["ModCode"]."</td>".
             "<td>".$row["Total_Count"]."</td>".
          
           "</tr>";
  }

 }
 else
 {
      echo "don't exist records for list on the table";
 }



// Pedictive report report start here
//echo '<br>'.'<br>';

require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT COUNT(TransactionID) 'TOTAL_COUNT',
                                    MONTHNAME(DateExam) 'EXAMS_SUBMISSIONS'
                                    FROM `exam_output`
                                    WHERE NULLIF(DateExam, '') IS NOT NULL
                                    GROUP BY EXAMS_SUBMISSIONS
                                    ORDER BY DateExam");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {

?>
<?php echo '<br>'.'<br>';?>




<div class="col-lg-12">
                <table class="table table-striped table-bordered table-hover">
                    <h3>Predictive Report </h3>
                  
                    <thead>
                    <tr>
                      
                        <th>Total</th>
                        <th>Exam Submission</th>
            
                    </tr>
                    </thead>
                <tbody>


 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["EXAMS_SUBMISSIONS"]."</td>".
          
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}




?>
            </div>
        </div>
    </div>

 </div>




<?php //include '../inc/footer.php'; ?>