<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/Exam.php');
	$exam = new Exam();
?>


<?php
//session_start();

//models
require_once("models/database.php");
require_once("models/adminModel.php");
require_once("models/studentsModel.php");
require_once("models/admissionModel.php");
require_once("models/modulesModel.php");
require_once("models/examsModel.php");
require_once("models/reportsModel.php");

$lecture = new Lecture();
$student = new Student();
$admission = new Admission();
$exam = new Exams();
$module = new Modules();
$reports = new Reports();

$action = null;

if(isset($_REQUEST['action'])) {

    if($_SERVER['REQUEST_METHOD'] == 'GET') {
        $action = filter_input(INPUT_GET, "action");
    }
    else {
        //get the request
        $action = filter_input(INPUT_POST, "action");
    }
    //processing the above reqeust
    if($action == "login") {
        include("views/loginPage.php");
    }
    else if($action == "student-logout"){
        if($student->student_logout()) {
            header("Location: index.php?action=login");
        }
        exit();
    }
    elseif($action == "student-login") {
        $email = filter_input(INPUT_POST, 'stud_email');
        $password = filter_input(INPUT_POST, 'stud_pass');

        // response arrary 
        $response = array();

        // validate the fields 
        if(empty($email) || empty($password)) {
            $response['status'] = 0;
            $response['message'] = "Please fill in your student email and password";
        }
        else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response['status'] = 0;
            $response['message'] = "Your email address {$email} is not valid.";
        }
        else{
            //call model to login user
            if($student->login($email, $password)['status'] != 0) {
                // include("views/student-dashboard.php");
                header("Location: index.php?action=student-home");
            }
            else {
                echo "Your credentials combination does not match";
            }
        }
        //echo json_encode($response); // display the message
    }
    else if($action == "student-home") {
        include("views/student-dashboard.php");
    }
    elseif($action == "student-modules") {
        include("views/modules.php");
    }
    elseif($action == "student-exams") {
        include("views/exams.php");
    }
    elseif($action == "start-exam") {
        include("views/exam_progress.php");
    }
    elseif($action == "exam-submit") {
        $DIR_PATH = "submissions"; //folder name

        $moduleCode = $_REQUEST['exam']; //module code

        $filename = $_FILES['filename']['name']; //file name to be uploaded

        $file_parts = explode('.', $filename); //separate document info in parts

        $file_ext = end($file_parts);

        //rewrite the document file name
        $filename = $_REQUEST['studentNumber']."_".$moduleCode."_".$_REQUEST['exam_date'].'.'.$file_ext;
        //directory full path for upload
        $targetPath = $DIR_PATH."/".$filename;

        if(!is_dir($DIR_PATH)) { //if directory does not exists
            mkdir($DIR_PATH); //else create the directory
        }
        if($exam->studentExamSubmission($_REQUEST['studentNumber'], $moduleCode, $filename)) {
            if(move_uploaded_file($_FILES['filename']['tmp_name'], $targetPath)) { //move file for upload
                echo "<script>alert('Your examination document has been submitted.')</script>"; //success message
                echo "<script>alert('Document: '".$filename."' has been uploaded.'')</script>";
            }
            else {
                echo "<script>alert('Failed to upload document: ".$filename."')</script>"; //error message on upload fail
            }
        }
        else {
            echo "<script>alert('Failed to submit your exam, please try again.')</script>"; //error message of fail to save
        }
        echo "<script>window.open('?action=end-exam','_self')</script>"; //redirect to page
    }
    elseif($action == "end-exam") {
        include("views/exam_end.php");
    }
    /* Lecture process */
    elseif($action == "lecture-login") {
        $email = $_REQUEST['lect_email'];
        $password = $_REQUEST['lect_pass'];
        if(in_array('', $_REQUEST)) {
            echo "Please type your email and password";
        }
        if($lecture->lectureLogin($email, $password)) {
           header("Location: ?action=lecturer-home"); exit();
        }
        else {
            echo "Invalid login credentials";
            header("Location: ?action=login");
        }
        exit();
    }
    else if($action == "lecturer-home") {

        include("views/lecturerDashboard.php"); 
    }
    else if($action == "list-exams") {
        include("views/addexam.php");
    }
    elseif ($action == "admissions-list") {
        include('views/admission_list.php');
    }
    else if($action == "exam-add") {

        $data = array(
            'module_code' => $_REQUEST['module_code'],
            'exam_type' => $_REQUEST['exam_type'],
            'exam_date' => $_REQUEST['exam_date'],
            'start_time' => $_REQUEST['start_time'],
            'end_time' => $_REQUEST['end_time'],
            'num_of_questions' => $_REQUEST['num_of_questions'],
        );
        if(in_array('', $data)) {
            echo "<script>alert('Please type all required data.')</script>";
            include("queslist.php?action=list-exams"); 
            exit();
        }

        $dir_path = "exams";
        $student_dir = "submissions";

        if(!is_dir($dir_path)) {
            mkdir($dir_path);
            mkdir($student_dir);
        }

        $filename = $_FILES['document_file']['name']; //collect the document file name

        $file_parts = explode('.', $filename); //separate document info in parts

        $file_ext = end($file_parts);

        //rewrite the document file name
        $filename = strtoupper($data['module_code'])."_".$data['exam_date']."_Exam.".$file_ext;

        $targetPath = $dir_path."/".$filename;

        if($exam->insertExam($data, $filename)) {
            if(move_uploaded_file($_FILES['document_file']['tmp_name'], $targetPath)) {
                echo "<script>alert('New examination has been added.')</script>";
                echo "<script>alert('Document '".$filename."' has been uploaded.'')</script>";
            }
            else {
                echo "<script>alert('Sorry failed to upload document.')</script>";
            }
        }
        echo "<script>window.open('?action=list-exams','_self')</script>";
        include("index.php"); 
        exit();
    }
    else if($action == "exam-update") {

        $data = array(
            'module_code' => $_REQUEST['module_code'],
            'exam_type' => $_REQUEST['exam_type'],
            'exam_date' => $_REQUEST['exam_date'],
            'start_time' => $_REQUEST['start_time'],
            'end_time' => $_REQUEST['end_time'],
            'num_of_questions' => $_REQUEST['num_of_questions'],
            'exam_id' => $_REQUEST['exam_id']
        );
        if(in_array('', $data)) {
            echo "<script>alert('Please type all required data.')</script>";
            include("index.php"); 
            exit();
        }
        if($exam->updateExamTable($data)) {
            echo "<script>alert('Examination has been updated.')</script>";
        }
        else {
            echo "<script>alert('Failed to update examination.')</script>";
        }
        echo "<script>window.open('?action=list-exams','_self')</script>";
    }
    else if($action == "change-document") {
        $examID = $_REQUEST['examID'];
        $filename = $_FILES['document_file']['name']; //collect the document file name
        if(empty($filename)) {
            echo "<script>alert('Please select file to upload.')</script>";
            echo "<script>window.open('?action=list-exams&edit=".$examID."','_self')</script>";
            exit();
        }

        $dir_path = "exams";

        if(!is_dir($dir_path)) {
            mkdir($dir_path);
        }

        $file_parts = explode('.', $filename); //separate document info in parts

        $file_ext = end($file_parts);

        //rewrite the document file name
        $filename = strtoupper($_REQUEST['module_code'])."_".$_REQUEST['exam_date']."_Exam.".$file_ext;

        $targetPath = $dir_path."/".$filename;

        if($exam->changeExamDocument($examID, $filename)) {
            if(move_uploaded_file($_FILES['document_file']['tmp_name'], $targetPath)) {
                echo "<script>alert('Examination has been updated.')</script>";
                echo "<script>alert('New Document '".$filename."' has been uploaded.'')</script>";
            }
            else{
                echo "<script>alert('Sorry failed to upload document.')</script>";
            }
        }
        else {
            echo "<script>alert('Sorry failed to update examination.')</script>";
        }
        echo "<script>window.open('?action=list-exams&edit=".$examID."','_self')</script>";
    }
    else if($action == "search-student") {
        $searchText = htmlentities(trim($_REQUEST['searchby']));
        $response = $student->searchStudent($searchText);
        if($response != 0) {
        foreach($response as $row):
    ?>
        <tr>
            <td><?php echo $row->student_number; ?></td>
            <td><?php echo $row->student_name.' '.$row->student_surname; ?></td>
            <td><?php echo $row->student_email; ?></td>
            <td><a href="?action=admissions-list&show_admission=<?php echo $row->student_number; ?>" class="btn btn-primary">Show</a></td>
        </tr>
    <?php
        endforeach;
        } else {
            echo "<tr><td colspan='4'><div class='alert alert-info text-center'><i class='fa fa-exclamation'></i> Sorry no match found</div></td></tr>";
        }
    }
    else if($action == "filter-student") {
        $searchText = htmlentities(trim($_REQUEST['searchby']));
        $response = $student->searchStudent($searchText);
        if($response != 0) {
        foreach($response as $row):
    ?>
        <tr>
            <td><?php echo $row->student_number; ?></td>
            <td><?php echo $row->student_name; ?></td>
            <td><?php echo $row->student_surname; ?></td>
            <td><?php echo $row->student_email; ?></td>
        </tr>
    <?php
        endforeach;
        } else {
            echo "<tr><td colspan='4'><div class='alert alert-info text-center'><i class='fa fa-exclamation'></i> Sorry no match found</div></td></tr>";
        }
    }
    elseif($action == "students-list") {
        include('views/students-list.php');
    }
    elseif($action == "modules-list") {
        include('views/modules-list.php');
    }
    elseif($action == "filter-modules") {
        $searchText = htmlentities(trim($_REQUEST['searchby']));
        $response = $module->searchModules($searchText);
        if($response != 0) {
        foreach($response as $row):
    ?>
        <tr>
            <td><?php echo $row->module_code; ?></td>
            <td><?php echo $row->module_name; ?></td>
        </tr>
    <?php
        endforeach;
        } else {
            echo "<tr><td colspan='4'><div class='alert alert-info text-center'><i class='fa fa-exclamation'></i> Sorry no match found</div></td></tr>";
        }
    }



}

//     else if($action == "reports") {
//         include("views/reports.php");
//     }
//     else if($action == "logout") {
//         $lecture->lectureLogout();
//         include("views/loginPage.php");
//     }
//     else{
//         include("views/loginPage.php");
//     }

// }
// else{
//     include("views/loginPage.php");
// }



?>



            </div>
        </div>
    </div>

<?php include '../inc/footer.php'; ?>