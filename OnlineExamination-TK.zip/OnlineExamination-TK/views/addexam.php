<?php

if(!isset($_SESSION['admin'])) {
    header("Location: ?action=login");
}

include ("topHeader.php");

$records = $exam->getAllExamRecords();
asort($records);
$modules = $module->getAllModules();

if(isset($_REQUEST['edit'])) {
    $edit = $exam->readExamRecords($_REQUEST['edit']);
    $exam_id = $edit->id;
    $module_code = $edit->module_code;
    $exam_type = $edit->exam_type;
    $exam_date = $edit->exam_date;
    $start_time = $edit->start_time;
    $end_time = $edit->end_time;
    $ques_num = $edit->number_of_questions;
    $filepath = $edit->file_document;
}
else {
    $exam_id = $module_code = $exam_type = $exam_date = $start_time = $end_time = $ques_num = $filepath =null;
}

?>

<!-- Page Content -->
<div class="container">

    <div class="row mb-2">

        <div class="col-lg-12">

            <h4 class="mt-2 text-light"><i class="fa fa-pencil"></i> Exams
                <a href="?action=list-exams&add" class="btn btn-success float-right"><i class="fa fa-plus"></i> Add Exam</a> 
                <?php if(isset($_REQUEST['edit']) || isset($_REQUEST['add'])) { ?>
                <a href="?action=list-exams" class="btn btn-warning float-right mr-3"><i class="fa fa-arrow-left"></i> List Exams</a>
                <?php } ?>
            </h4><hr>

            <div class="card h-85 mt-1">
                <div class="card-body">
                    <?php if(!isset($_REQUEST['add']) && !isset($_REQUEST['edit'])) { ?>
                    <div class="lead">List Upcoming Examinations
                        <a href="?action=lecturer-home" class="btn btn-sm btn-dark float-right"><i class="fa fa-home"></i> Home</a></div><hr>
                    <?php if($records != false) { ?>
                        <table class="table table-bordered" id="dt_table">
                        <th>Module</th><th>Type</th><th>Date</th><th>StartTime</th>
                        <th>EndTime</th><th>Total Questions</th><th></th>
                        <?php foreach($records as $rec): ?>
                        <tr>
                            <td><?php echo $rec->module_code; ?></td>
                            <td><?php echo $rec->exam_type; ?></td>
                            <td><?php echo date('d/m/Y', strtotime($rec->exam_date)); ?></td>
                            <td><?php echo date('H:i A', strtotime($rec->start_time)); ?></td>
                            <td><?php echo date('H:i A', strtotime($rec->end_time)); ?></td>
                            <td><?php echo $rec->number_of_questions; ?></td>
                            <td><a href="?action=list-exams&edit=<?php echo $rec->id; ?>" class="btn btn-primary">Update</a></td>
                        </tr>
                        <?php endforeach; ?>
                        </table>
                        <?php } else { ?>
                            <tr><td><div class="alert alert-info">No upcoming exams available at the moment.</div></td></tr>
                        <?php } ?>

                    <?php } else { ?>
                        <div>
                            <div class="lead">Add/Edit New Exam 2022</div><hr>
                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                                    <select class="form-control" name="module_code">
                                        <option value="">Select Module</option>
                                        <?php foreach($modules as $data): 
                                            $selected = ($data->module_code==$module_code) ? 'selected' : '';
                                        ?>
                                        <option <?php echo $selected; ?> value="<?php echo $data->module_code; ?>">
                                            <?php echo $data->module_code.' - '.$data->module_name; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <select class="form-control" name="exam_type">
                                        <option value="">Select Exam Type</option>
                                        <option <?php echo ($exam_type=="MCQ") ? 'selected' : ''; ?> value="MCQ">MCQ</option>
                                        <option <?php echo ($exam_type=="Fill-In") ? 'selected' : ''; ?> value="Fill-In">Fill In</option>
                                        <option <?php echo ($exam_type=="Document-Upload") ? 'selected' : ''; ?> value="Document-Upload">Document Upload</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <input type="date" class="form-control" name="exam_date" placeholder="" value="<?php echo $exam_date; ?>">
                                </div>
                                <div class="mb-3">
                                    <input type="time" class="form-control" name="start_time" placeholder="" value="<?php echo $start_time; ?>">
                                </div>
                                <div class="mb-3">
                                    <input type="time" class="form-control" name="end_time" placeholder="" value="<?php echo $end_time; ?>">
                                </div>
                                <div class="mb-3">
                                    <input type="number" class="form-control" name="num_of_questions" placeholder="Total questions" value="<?php echo $ques_num; ?>">
                                </div>
                                <div class="mb-3">
                                    <?php if(isset($_REQUEST['edit'])) { ?>
                                        <div class="text-muted text-center mt-3">Uploaded Document: 
                                            <a href="exams/<?php echo $filepath; ?>"><?php echo $filepath; ?></a>
                                            <a href="javascript:" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#updateImage" data-examid="<?php echo $exam_id; ?>">Change Document</a>
                                        </div>
                                    <?php } else { ?>
                                        <input type="file" class="form-control" name="document_file" accept=".pdf" required>
                                        <small class="text-muted">**Only PDF Documents allowed.</small>
                                    <?php } ?>
                                </div>
                                <div class="">
                                    <?php if(!isset($_REQUEST['edit'])) { ?>
                                    <button type="submit" class="btn btn-success" name="action" value="exam-add">Add Exam</button>
                                    <?php } else { ?>
                                    <button type="submit" class="btn btn-primary" name="action" value="exam-update">Update Exam</button>
                                    <?php } ?>
                                </div>
                            </form>
                        </div>

                    <?php } ?>
                </div>
            </div>
            <br>
        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->

<!-- second Modal -->
<div class="modal fade" id="updateImage" aria-hidden="true" aria-labelledby="updateImage" tabindex="-1">
  <div class="modal-dialog modal-m">
    <div class="modal-content">
    <form action="" method="POST" enctype="multipart/form-data">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalToggleLabel2">Change Uploaded Document</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group mt-2">
            <input type="hidden" class="form-control" name="examID" readonly id="examID" value="<?php echo $exam_id; ?>">
            <input type="hidden" name="module_code" value="<?php echo $module_code; ?>">
            <input type="hidden" name="exam_date" value="<?php echo $exam_date; ?>">
        </div>
        <div class="form-group mt-2">
            <input type="file" class="form-control" name="document_file" accept=".pdf" required>
            <small class="text-muted">**Only PDF Documents allowed.</small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger"data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-success" name="action" value="change-document"><i class="fa fa-refresh"></i> Change Document</button>
      </div>
    </form>
    </div>
  </div>
</div>

<script src="assets/js/jquery-3.6.js"></script>
<script src="assets/js/jquery-1.12.4.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/datatables/datatables.min.js"></script>
<?php # include ("footer.php"); ?>

<script type="text/javascript">
    $(function() {

        $('#dt_table').DataTable();

         $('#updateImage').on('show.bs.modal', function(event) {
            var eventAction = $(event.relatedTarget)
            var examID = eventAction.data('examid');
            var jobDate = eventAction.data('date');
            $('#examID').val(examID);
            $('#jobDate').val(jobDate);
        });
    })
</script>